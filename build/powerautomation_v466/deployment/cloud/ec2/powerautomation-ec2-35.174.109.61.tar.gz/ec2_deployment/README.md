# PowerAutomation Website EC2 部署指南

## 📋 概述

这是PowerAutomation + ClaudEditor官方网站的EC2部署包，包含完整的生产环境配置。

## 🚀 快速部署

### 1. 准备EC2实例

**推荐配置:**
- **实例类型**: t3.medium 或更高
- **操作系统**: Ubuntu 20.04 LTS 或 22.04 LTS
- **存储**: 至少20GB SSD
- **安全组**: 开放端口 22 (SSH), 80 (HTTP), 443 (HTTPS)

### 2. 连接到EC2实例

```bash
ssh -i your-key.pem ubuntu@your-ec2-ip
```

### 3. 上传部署文件

```bash
# 方法1: 使用scp
scp -i your-key.pem -r ./ec2_deployment ubuntu@your-ec2-ip:~/

# 方法2: 使用git (推荐)
git clone your-repository-url
cd your-repository
```

### 4. 运行部署脚本

```bash
cd ec2_deployment
chmod +x deploy.sh
./deploy.sh production
```

## 📁 文件结构

```
ec2_deployment/
├── index.html              # 网站主页面
├── package.json            # Node.js依赖配置
├── server.js               # Express服务器
├── Dockerfile              # Docker镜像配置
├── docker-compose.yml      # Docker Compose配置
├── deploy.sh               # 自动部署脚本
├── .env.example            # 环境变量示例
├── nginx/                  # Nginx配置
│   ├── nginx.conf          # 主配置文件
│   └── sites-available/    # 站点配置
└── public/                 # 静态资源目录
    ├── css/
    ├── js/
    └── images/
```

## ⚙️ 配置说明

### 环境变量配置

复制并编辑环境变量文件:

```bash
cp .env.example .env
nano .env
```

**重要配置项:**
- `DOMAIN`: 您的域名
- `NODE_ENV`: 环境 (production/staging)
- `PORT`: 应用端口 (默认3000)

### SSL证书配置

**开发/测试环境:**
部署脚本会自动生成自签名证书

**生产环境 (推荐使用Let's Encrypt):**

```bash
# 安装certbot
sudo apt install certbot python3-certbot-nginx

# 获取SSL证书
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# 自动续期
sudo crontab -e
# 添加: 0 12 * * * /usr/bin/certbot renew --quiet
```

### 域名配置

1. 在您的域名提供商处配置DNS:
   ```
   A记录: yourdomain.com -> EC2公网IP
   A记录: www.yourdomain.com -> EC2公网IP
   ```

2. 更新Nginx配置中的域名:
   ```bash
   sudo nano /opt/powerautomation/nginx/sites-available/powerautomation.conf
   # 将 yourdomain.com 替换为您的实际域名
   ```

## 🔧 管理命令

### 服务管理

```bash
# 查看服务状态
sudo systemctl status powerautomation

# 启动服务
sudo systemctl start powerautomation

# 停止服务
sudo systemctl stop powerautomation

# 重启服务
sudo systemctl restart powerautomation

# 查看服务日志
sudo journalctl -u powerautomation -f
```

### Docker管理

```bash
cd /opt/powerautomation

# 查看容器状态
docker-compose ps

# 查看日志
docker-compose logs -f

# 重启容器
docker-compose restart

# 重新构建并启动
docker-compose down
docker-compose build
docker-compose up -d
```

### 应用更新

```bash
cd /opt/powerautomation

# 拉取最新代码
git pull origin main

# 重新构建并部署
docker-compose down
docker-compose build
docker-compose up -d
```

## 📊 监控和维护

### 健康检查

访问健康检查端点:
```
http://your-domain/health
```

### 日志查看

```bash
# 应用日志
docker-compose logs powerautomation-web

# Nginx日志
docker-compose logs nginx

# 系统日志
tail -f /opt/powerautomation/logs/nginx/access.log
tail -f /opt/powerautomation/logs/nginx/error.log
```

### 性能监控

```bash
# 查看资源使用
docker stats

# 查看磁盘使用
df -h

# 查看内存使用
free -h

# 查看CPU使用
top
```

## 🔒 安全配置

### 防火墙设置

```bash
# 查看防火墙状态
sudo ufw status

# 允许特定IP访问SSH (推荐)
sudo ufw allow from YOUR_IP to any port 22

# 删除默认SSH规则
sudo ufw delete allow ssh
```

### 定期更新

```bash
# 系统更新
sudo apt update && sudo apt upgrade -y

# Docker镜像更新
docker-compose pull
docker-compose up -d
```

## 🚨 故障排除

### 常见问题

1. **端口被占用**
   ```bash
   sudo netstat -tlnp | grep :80
   sudo netstat -tlnp | grep :443
   ```

2. **Docker服务未启动**
   ```bash
   sudo systemctl start docker
   sudo systemctl enable docker
   ```

3. **权限问题**
   ```bash
   sudo chown -R $USER:$USER /opt/powerautomation
   ```

4. **SSL证书问题**
   ```bash
   # 检查证书有效性
   openssl x509 -in /opt/powerautomation/nginx/ssl/yourdomain.crt -text -noout
   ```

### 日志分析

```bash
# 查看错误日志
grep -i error /opt/powerautomation/logs/nginx/error.log

# 查看访问日志
tail -f /opt/powerautomation/logs/nginx/access.log

# 查看应用日志
docker-compose logs powerautomation-web | grep -i error
```

## 📞 支持

如果遇到问题，请检查:

1. **系统要求**: Ubuntu 20.04+, 2GB+ RAM, 20GB+ 存储
2. **网络配置**: 安全组开放正确端口
3. **域名解析**: DNS配置正确
4. **SSL证书**: 证书有效且未过期

## 📝 更新日志

- **v1.0.0**: 初始版本，包含基础部署功能
- **v1.1.0**: 添加SSL支持和安全配置
- **v1.2.0**: 优化Docker配置和监控功能

---

**PowerAutomation Team**  
© 2024 PowerAutomation + ClaudEditor


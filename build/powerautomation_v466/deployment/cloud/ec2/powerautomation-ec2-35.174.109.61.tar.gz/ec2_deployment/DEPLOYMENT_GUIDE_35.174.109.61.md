# PowerAutomation Website 部署指南
## 服务器: 35.174.109.61 (Amazon Linux)

## 🚀 快速部署步骤

### 1. 连接到EC2服务器

```bash
ssh -i "alexchuang.pem" ec2-user@35.174.109.61
```

### 2. 上传部署文件

**方法1: 使用scp上传部署包**
```bash
# 在本地执行
scp -i "alexchuang.pem" powerautomation-ec2-deployment.tar.gz ec2-user@35.174.109.61:~/
```

**方法2: 直接在服务器上下载**
```bash
# 在服务器上执行
wget https://your-download-link/powerautomation-ec2-deployment.tar.gz
```

### 3. 解压并部署

```bash
# 在服务器上执行
tar -xzf powerautomation-ec2-deployment.tar.gz
cd ec2_deployment
chmod +x deploy-amazon-linux.sh
./deploy-amazon-linux.sh
```

## 📋 部署前检查清单

### EC2安全组配置
确保以下端口已开放:
- **22** (SSH) - 用于远程管理
- **80** (HTTP) - 网站访问
- **443** (HTTPS) - 安全网站访问

### 系统要求
- **操作系统**: Amazon Linux 2
- **内存**: 至少 2GB RAM
- **存储**: 至少 20GB 可用空间
- **网络**: 稳定的互联网连接

## 🔧 部署过程详解

### 自动安装的组件
1. **Docker** - 容器化平台
2. **Docker Compose** - 容器编排工具
3. **Node.js 18.x** - JavaScript运行环境
4. **Nginx** - 反向代理服务器
5. **SSL证书** - 自签名证书(测试用)

### 创建的目录结构
```
/opt/powerautomation/
├── index.html              # 网站主页
├── server.js               # Express服务器
├── package.json            # Node.js依赖
├── docker-compose.yml      # Docker配置
├── .env                    # 环境变量
├── nginx/                  # Nginx配置
│   ├── nginx.conf
│   ├── sites-available/
│   └── ssl/
└── logs/                   # 日志目录
```

## 🌐 访问网站

部署完成后，您可以通过以下地址访问:

- **HTTP**: http://35.174.109.61
- **HTTPS**: https://35.174.109.61
- **健康检查**: http://35.174.109.61/health

## 📊 管理和监控

### 服务管理命令

```bash
# 查看服务状态
sudo systemctl status powerautomation

# 启动服务
sudo systemctl start powerautomation

# 停止服务
sudo systemctl stop powerautomation

# 重启服务
sudo systemctl restart powerautomation
```

### Docker管理命令

```bash
cd /opt/powerautomation

# 查看容器状态
docker-compose ps

# 查看实时日志
docker-compose logs -f

# 重启特定服务
docker-compose restart powerautomation-web
docker-compose restart nginx

# 完全重新部署
docker-compose down
docker-compose build
docker-compose up -d
```

### 日志查看

```bash
# 应用日志
docker-compose logs powerautomation-web

# Nginx访问日志
tail -f /opt/powerautomation/logs/nginx/access.log

# Nginx错误日志
tail -f /opt/powerautomation/logs/nginx/error.log

# 系统服务日志
sudo journalctl -u powerautomation -f
```

## 🔒 安全配置

### 防火墙状态检查

```bash
# 检查firewalld状态
sudo firewall-cmd --list-all

# 检查开放端口
sudo firewall-cmd --list-ports
```

### SSL证书管理

当前使用自签名证书，生产环境建议使用Let's Encrypt:

```bash
# 安装certbot
sudo yum install -y certbot python3-certbot-nginx

# 获取免费SSL证书 (需要域名)
sudo certbot --nginx -d yourdomain.com

# 设置自动续期
echo "0 12 * * * /usr/bin/certbot renew --quiet" | sudo crontab -
```

## 🚨 故障排除

### 常见问题及解决方案

1. **无法访问网站**
   ```bash
   # 检查服务状态
   docker-compose ps
   
   # 检查端口监听
   sudo netstat -tlnp | grep :80
   sudo netstat -tlnp | grep :443
   
   # 检查防火墙
   sudo firewall-cmd --list-all
   ```

2. **Docker权限问题**
   ```bash
   # 重新登录以获取docker组权限
   exit
   ssh -i "alexchuang.pem" ec2-user@35.174.109.61
   
   # 或者临时使用sudo
   sudo docker-compose ps
   ```

3. **服务启动失败**
   ```bash
   # 查看详细错误日志
   docker-compose logs
   
   # 检查磁盘空间
   df -h
   
   # 检查内存使用
   free -h
   ```

4. **SSL证书错误**
   ```bash
   # 重新生成自签名证书
   cd /opt/powerautomation/nginx/ssl
   sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
       -keyout server.key -out server.crt \
       -subj "/C=US/ST=Virginia/L=Virginia/O=PowerAutomation/CN=35.174.109.61"
   
   # 重启nginx
   docker-compose restart nginx
   ```

## 📈 性能优化

### 监控资源使用

```bash
# 查看容器资源使用
docker stats

# 查看系统负载
top
htop

# 查看磁盘IO
iostat -x 1

# 查看网络连接
ss -tuln
```

### 优化建议

1. **启用Gzip压缩** - 已在Nginx配置中启用
2. **设置缓存头** - 静态文件缓存1年
3. **使用CDN** - 建议生产环境使用
4. **数据库优化** - 如需要数据库功能

## 🔄 更新和维护

### 应用更新流程

```bash
# 1. 备份当前版本
sudo cp -r /opt/powerautomation /opt/powerautomation.backup.$(date +%Y%m%d)

# 2. 上传新版本文件
scp -i "alexchuang.pem" new-files.tar.gz ec2-user@35.174.109.61:~/

# 3. 解压并替换
tar -xzf new-files.tar.gz
sudo cp -r new-files/* /opt/powerautomation/

# 4. 重新构建并启动
cd /opt/powerautomation
docker-compose down
docker-compose build
docker-compose up -d
```

### 定期维护任务

```bash
# 系统更新 (每月)
sudo yum update -y

# Docker镜像清理 (每周)
docker system prune -f

# 日志轮转 (自动)
# 已在docker-compose.yml中配置

# 备份配置文件 (每天)
sudo tar -czf /home/ec2-user/backup-$(date +%Y%m%d).tar.gz /opt/powerautomation
```

## 📞 技术支持

### 联系信息
- **服务器IP**: 35.174.109.61
- **SSH用户**: ec2-user
- **应用端口**: 3000 (内部), 80/443 (外部)
- **部署时间**: $(date)

### 有用的命令速查

```bash
# 快速重启整个应用
sudo systemctl restart powerautomation

# 查看最新日志
docker-compose logs --tail=50 -f

# 检查网站响应
curl -I http://35.174.109.61

# 进入容器调试
docker-compose exec powerautomation-web bash

# 查看容器内进程
docker-compose exec powerautomation-web ps aux
```

---

**部署完成后请保存此文档以备后续维护使用！**

PowerAutomation Team © 2024


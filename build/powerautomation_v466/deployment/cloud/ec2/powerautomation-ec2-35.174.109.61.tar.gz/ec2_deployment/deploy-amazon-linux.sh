#!/bin/bash

# PowerAutomation Website Amazon Linux EC2 部署脚本
# 服务器: 35.174.109.61
# 用户: ec2-user
# 使用方法: ./deploy-amazon-linux.sh

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 服务器信息
SERVER_IP="35.174.109.61"
SERVER_USER="ec2-user"

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查系统要求
check_requirements() {
    log_info "检查Amazon Linux系统要求..."
    
    # 检查操作系统
    if [[ -f /etc/os-release ]]; then
        source /etc/os-release
        log_info "操作系统: $PRETTY_NAME"
    fi
    
    # 检查必要命令
    local required_commands=("curl" "sudo")
    for cmd in "${required_commands[@]}"; do
        if ! command -v "$cmd" &> /dev/null; then
            log_error "缺少必要命令: $cmd"
            exit 1
        fi
    done
    
    log_success "系统要求检查通过"
}

# 更新系统
update_system() {
    log_info "更新系统包..."
    sudo yum update -y
    log_success "系统更新完成"
}

# 安装基础工具
install_basic_tools() {
    log_info "安装基础工具..."
    sudo yum install -y \
        git \
        wget \
        curl \
        unzip \
        tar \
        htop \
        nano \
        tree
    log_success "基础工具安装完成"
}

# 安装Docker
install_docker() {
    if command -v docker &> /dev/null; then
        log_info "Docker已安装，跳过安装步骤"
        return
    fi
    
    log_info "安装Docker..."
    
    # 安装Docker
    sudo yum install -y docker
    
    # 启动Docker服务
    sudo systemctl start docker
    sudo systemctl enable docker
    
    # 将ec2-user添加到docker组
    sudo usermod -aG docker ec2-user
    
    log_success "Docker安装完成"
    log_warning "请重新登录以使docker组权限生效"
}

# 安装Docker Compose
install_docker_compose() {
    if command -v docker-compose &> /dev/null; then
        log_info "Docker Compose已安装，跳过安装步骤"
        return
    fi
    
    log_info "安装Docker Compose..."
    
    # 下载Docker Compose
    sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    
    # 添加执行权限
    sudo chmod +x /usr/local/bin/docker-compose
    
    # 创建符号链接
    sudo ln -sf /usr/local/bin/docker-compose /usr/bin/docker-compose
    
    log_success "Docker Compose安装完成"
}

# 安装Node.js
install_nodejs() {
    if command -v node &> /dev/null; then
        local node_version=$(node --version)
        log_info "Node.js已安装: $node_version"
        return
    fi
    
    log_info "安装Node.js..."
    
    # 安装Node.js 18.x
    curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
    sudo yum install -y nodejs
    
    log_success "Node.js安装完成"
}

# 配置防火墙
configure_firewall() {
    log_info "配置防火墙..."
    
    # Amazon Linux 2使用firewalld
    if command -v firewall-cmd &> /dev/null; then
        sudo systemctl start firewalld
        sudo systemctl enable firewalld
        
        # 配置防火墙规则
        sudo firewall-cmd --permanent --add-service=http
        sudo firewall-cmd --permanent --add-service=https
        sudo firewall-cmd --permanent --add-service=ssh
        sudo firewall-cmd --reload
        
        log_success "firewalld防火墙配置完成"
    else
        # 如果没有firewalld，使用iptables
        log_warning "未找到firewalld，请手动配置安全组规则"
    fi
}

# 创建应用目录
setup_app_directory() {
    local app_dir="/opt/powerautomation"
    
    log_info "设置应用目录..."
    
    # 创建应用目录
    sudo mkdir -p "$app_dir"
    sudo chown ec2-user:ec2-user "$app_dir"
    
    # 复制应用文件
    cp -r ./* "$app_dir/" 2>/dev/null || true
    
    # 设置权限
    chmod +x "$app_dir/deploy-amazon-linux.sh" 2>/dev/null || true
    
    log_success "应用目录设置完成: $app_dir"
}

# 配置环境变量
setup_environment() {
    local env_file="/opt/powerautomation/.env"
    
    log_info "配置环境变量..."
    
    if [[ ! -f "$env_file" ]]; then
        cat > "$env_file" << EOF
# PowerAutomation Website Environment Configuration
NODE_ENV=production
PORT=3000
DOMAIN=$SERVER_IP
SERVER_IP=$SERVER_IP
EOF
        log_success "环境变量文件创建完成"
    fi
    
    log_success "环境变量配置完成"
}

# 配置SSL证书
setup_ssl() {
    log_info "配置SSL证书..."
    
    local ssl_dir="/opt/powerautomation/nginx/ssl"
    sudo mkdir -p "$ssl_dir"
    
    # 创建自签名证书
    if [[ ! -f "$ssl_dir/server.crt" ]]; then
        sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
            -keyout "$ssl_dir/server.key" \
            -out "$ssl_dir/server.crt" \
            -subj "/C=US/ST=Virginia/L=Virginia/O=PowerAutomation/CN=$SERVER_IP"
        
        sudo chown -R ec2-user:ec2-user "$ssl_dir"
        log_success "SSL证书创建完成"
    fi
}

# 更新Nginx配置
update_nginx_config() {
    log_info "更新Nginx配置..."
    
    local nginx_config="/opt/powerautomation/nginx/sites-available/powerautomation.conf"
    
    # 更新配置文件中的域名
    if [[ -f "$nginx_config" ]]; then
        sed -i "s/yourdomain.com/$SERVER_IP/g" "$nginx_config"
        sed -i "s/yourdomain.crt/server.crt/g" "$nginx_config"
        sed -i "s/yourdomain.key/server.key/g" "$nginx_config"
        log_success "Nginx配置更新完成"
    fi
}

# 启动服务
start_services() {
    log_info "启动服务..."
    
    cd /opt/powerautomation
    
    # 确保Docker服务运行
    sudo systemctl start docker
    
    # 构建并启动容器
    docker-compose build
    docker-compose up -d
    
    # 等待服务启动
    sleep 15
    
    # 检查服务状态
    if docker-compose ps | grep -q "Up"; then
        log_success "服务启动成功"
    else
        log_error "服务启动失败，查看日志:"
        docker-compose logs
        exit 1
    fi
}

# 配置系统服务
setup_systemd_service() {
    log_info "配置系统服务..."
    
    cat << EOF | sudo tee /etc/systemd/system/powerautomation.service > /dev/null
[Unit]
Description=PowerAutomation Website
Requires=docker.service
After=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/opt/powerautomation
ExecStart=/usr/local/bin/docker-compose up -d
ExecStop=/usr/local/bin/docker-compose down
TimeoutStartSec=0
User=ec2-user
Group=ec2-user

[Install]
WantedBy=multi-user.target
EOF
    
    # 重新加载systemd并启用服务
    sudo systemctl daemon-reload
    sudo systemctl enable powerautomation.service
    
    log_success "系统服务配置完成"
}

# 显示部署信息
show_deployment_info() {
    log_success "PowerAutomation网站部署完成！"
    echo
    echo "=========================================="
    echo "部署信息:"
    echo "- 服务器IP: $SERVER_IP"
    echo "- 应用目录: /opt/powerautomation"
    echo "- 配置文件: /opt/powerautomation/.env"
    echo "- 日志目录: /opt/powerautomation/logs"
    echo
    echo "访问地址:"
    echo "- HTTP: http://$SERVER_IP"
    echo "- HTTPS: https://$SERVER_IP"
    echo
    echo "管理命令:"
    echo "- 查看容器状态: docker-compose ps"
    echo "- 查看日志: docker-compose logs -f"
    echo "- 重启服务: sudo systemctl restart powerautomation"
    echo "- 停止服务: sudo systemctl stop powerautomation"
    echo
    echo "健康检查:"
    echo "- curl http://$SERVER_IP/health"
    echo "- curl https://$SERVER_IP/health"
    echo "=========================================="
    echo
    log_warning "重要提醒:"
    echo "1. 请确保EC2安全组开放了80和443端口"
    echo "2. 如需域名访问，请配置DNS指向 $SERVER_IP"
    echo "3. 生产环境建议使用真实SSL证书"
    echo "4. 定期备份 /opt/powerautomation 目录"
}

# 主函数
main() {
    echo "=========================================="
    echo "PowerAutomation Website Amazon Linux 部署"
    echo "服务器: $SERVER_IP"
    echo "用户: $SERVER_USER"
    echo "=========================================="
    
    check_requirements
    update_system
    install_basic_tools
    install_docker
    install_docker_compose
    install_nodejs
    configure_firewall
    setup_app_directory
    setup_environment
    setup_ssl
    update_nginx_config
    start_services
    setup_systemd_service
    show_deployment_info
    
    log_success "部署完成！请访问 http://$SERVER_IP 查看网站"
}

# 运行主函数
main "$@"


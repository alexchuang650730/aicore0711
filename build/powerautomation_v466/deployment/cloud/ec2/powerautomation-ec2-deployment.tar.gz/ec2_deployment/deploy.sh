#!/bin/bash

# PowerAutomation Website EC2 部署脚本
# 使用方法: ./deploy.sh [production|staging]

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查是否为root用户
check_root() {
    if [[ $EUID -eq 0 ]]; then
        log_error "请不要使用root用户运行此脚本"
        exit 1
    fi
}

# 检查系统要求
check_requirements() {
    log_info "检查系统要求..."
    
    # 检查操作系统
    if [[ ! -f /etc/os-release ]]; then
        log_error "无法确定操作系统版本"
        exit 1
    fi
    
    source /etc/os-release
    if [[ "$ID" != "ubuntu" ]] && [[ "$ID" != "debian" ]]; then
        log_warning "此脚本主要为Ubuntu/Debian设计，其他系统可能需要调整"
    fi
    
    # 检查必要命令
    local required_commands=("curl" "git" "sudo")
    for cmd in "${required_commands[@]}"; do
        if ! command -v "$cmd" &> /dev/null; then
            log_error "缺少必要命令: $cmd"
            exit 1
        fi
    done
    
    log_success "系统要求检查通过"
}

# 安装Docker
install_docker() {
    if command -v docker &> /dev/null; then
        log_info "Docker已安装，跳过安装步骤"
        return
    fi
    
    log_info "安装Docker..."
    
    # 更新包索引
    sudo apt-get update
    
    # 安装必要的包
    sudo apt-get install -y \
        apt-transport-https \
        ca-certificates \
        curl \
        gnupg \
        lsb-release
    
    # 添加Docker官方GPG密钥
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
    
    # 设置稳定版仓库
    echo \
        "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
        $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
    
    # 安装Docker Engine
    sudo apt-get update
    sudo apt-get install -y docker-ce docker-ce-cli containerd.io
    
    # 将当前用户添加到docker组
    sudo usermod -aG docker $USER
    
    log_success "Docker安装完成"
}

# 安装Docker Compose
install_docker_compose() {
    if command -v docker-compose &> /dev/null; then
        log_info "Docker Compose已安装，跳过安装步骤"
        return
    fi
    
    log_info "安装Docker Compose..."
    
    # 下载Docker Compose
    sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    
    # 添加执行权限
    sudo chmod +x /usr/local/bin/docker-compose
    
    log_success "Docker Compose安装完成"
}

# 安装Node.js
install_nodejs() {
    if command -v node &> /dev/null; then
        local node_version=$(node --version)
        log_info "Node.js已安装: $node_version"
        return
    fi
    
    log_info "安装Node.js..."
    
    # 安装NodeSource仓库
    curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
    
    # 安装Node.js
    sudo apt-get install -y nodejs
    
    log_success "Node.js安装完成"
}

# 配置防火墙
configure_firewall() {
    log_info "配置防火墙..."
    
    # 检查ufw是否安装
    if ! command -v ufw &> /dev/null; then
        sudo apt-get install -y ufw
    fi
    
    # 配置防火墙规则
    sudo ufw default deny incoming
    sudo ufw default allow outgoing
    sudo ufw allow ssh
    sudo ufw allow 80/tcp
    sudo ufw allow 443/tcp
    
    # 启用防火墙
    sudo ufw --force enable
    
    log_success "防火墙配置完成"
}

# 创建应用目录
setup_app_directory() {
    local app_dir="/opt/powerautomation"
    
    log_info "设置应用目录..."
    
    # 创建应用目录
    sudo mkdir -p "$app_dir"
    sudo chown $USER:$USER "$app_dir"
    
    # 复制应用文件
    cp -r ./* "$app_dir/"
    
    # 设置权限
    chmod +x "$app_dir/deploy.sh"
    
    log_success "应用目录设置完成: $app_dir"
}

# 配置环境变量
setup_environment() {
    local env_file="/opt/powerautomation/.env"
    
    log_info "配置环境变量..."
    
    if [[ ! -f "$env_file" ]]; then
        cp /opt/powerautomation/.env.example "$env_file"
        log_warning "请编辑 $env_file 文件配置您的环境变量"
    fi
    
    log_success "环境变量配置完成"
}

# 配置SSL证书
setup_ssl() {
    log_info "配置SSL证书..."
    
    local ssl_dir="/opt/powerautomation/nginx/ssl"
    
    # 创建自签名证书（仅用于测试）
    if [[ ! -f "$ssl_dir/yourdomain.crt" ]]; then
        sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
            -keyout "$ssl_dir/yourdomain.key" \
            -out "$ssl_dir/yourdomain.crt" \
            -subj "/C=CN/ST=Beijing/L=Beijing/O=PowerAutomation/CN=yourdomain.com"
        
        log_warning "已创建自签名SSL证书，生产环境请使用Let's Encrypt或购买证书"
    fi
    
    log_success "SSL证书配置完成"
}

# 启动服务
start_services() {
    log_info "启动服务..."
    
    cd /opt/powerautomation
    
    # 构建并启动容器
    docker-compose build
    docker-compose up -d
    
    # 等待服务启动
    sleep 10
    
    # 检查服务状态
    if docker-compose ps | grep -q "Up"; then
        log_success "服务启动成功"
    else
        log_error "服务启动失败"
        docker-compose logs
        exit 1
    fi
}

# 配置系统服务
setup_systemd_service() {
    log_info "配置系统服务..."
    
    cat << EOF | sudo tee /etc/systemd/system/powerautomation.service > /dev/null
[Unit]
Description=PowerAutomation Website
Requires=docker.service
After=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/opt/powerautomation
ExecStart=/usr/local/bin/docker-compose up -d
ExecStop=/usr/local/bin/docker-compose down
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
EOF
    
    # 重新加载systemd并启用服务
    sudo systemctl daemon-reload
    sudo systemctl enable powerautomation.service
    
    log_success "系统服务配置完成"
}

# 显示部署信息
show_deployment_info() {
    log_success "PowerAutomation网站部署完成！"
    echo
    echo "部署信息:"
    echo "- 应用目录: /opt/powerautomation"
    echo "- 配置文件: /opt/powerautomation/.env"
    echo "- 日志目录: /opt/powerautomation/logs"
    echo "- 服务状态: sudo systemctl status powerautomation"
    echo
    echo "访问地址:"
    echo "- HTTP: http://$(curl -s ifconfig.me)"
    echo "- HTTPS: https://$(curl -s ifconfig.me)"
    echo
    echo "管理命令:"
    echo "- 查看日志: docker-compose logs -f"
    echo "- 重启服务: sudo systemctl restart powerautomation"
    echo "- 停止服务: sudo systemctl stop powerautomation"
    echo
    log_warning "请记得:"
    echo "1. 配置您的域名DNS指向此服务器IP"
    echo "2. 更新 /opt/powerautomation/.env 文件中的配置"
    echo "3. 为生产环境配置真实的SSL证书"
    echo "4. 定期备份应用数据和配置"
}

# 主函数
main() {
    local environment=${1:-production}
    
    echo "=========================================="
    echo "PowerAutomation Website EC2 部署脚本"
    echo "环境: $environment"
    echo "=========================================="
    
    check_root
    check_requirements
    install_docker
    install_docker_compose
    install_nodejs
    configure_firewall
    setup_app_directory
    setup_environment
    setup_ssl
    start_services
    setup_systemd_service
    show_deployment_info
    
    log_success "部署完成！"
}

# 运行主函数
main "$@"


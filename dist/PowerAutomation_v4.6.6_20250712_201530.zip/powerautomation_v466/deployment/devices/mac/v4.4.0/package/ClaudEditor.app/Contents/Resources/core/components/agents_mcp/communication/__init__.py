"""
PowerAutomation 4.0 Agent Communication
智能体通信模块
"""

__version__ = "4.0.0"


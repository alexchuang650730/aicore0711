"""
PowerAutomation 4.0 Agent
"""

__version__ = "4.0.0"

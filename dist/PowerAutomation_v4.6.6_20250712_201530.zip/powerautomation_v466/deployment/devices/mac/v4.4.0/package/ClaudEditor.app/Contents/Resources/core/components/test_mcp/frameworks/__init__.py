"""
PowerAutomation 4.0 Test Suite

测试套件包含：
- UI操作测试
- 集成测试
- 端到端测试
- 性能测试
"""

__version__ = "1.0.0"
__author__ = "PowerAutomation 4.0 Team"


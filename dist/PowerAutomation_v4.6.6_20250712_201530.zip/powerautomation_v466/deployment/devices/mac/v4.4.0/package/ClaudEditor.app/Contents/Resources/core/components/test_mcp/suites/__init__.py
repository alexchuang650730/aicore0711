"""
PowerAutomation 4.0 测试模块

包含所有核心组件的单元测试、集成测试、性能测试和安全测试。
"""

__version__ = "4.0.0"
__author__ = "PowerAutomation Team"

